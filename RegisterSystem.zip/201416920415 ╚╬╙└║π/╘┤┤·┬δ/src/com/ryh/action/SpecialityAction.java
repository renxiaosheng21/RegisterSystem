package com.ryh.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ryh.bean.Speciality;
import com.ryh.db.DBConn;

public class SpecialityAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	public String specialityname;
	public int specialityid;
	public String action;
	public ArrayList<Speciality> specParamArray;

	public ArrayList<Speciality> getSpecParamArray() {
		return specParamArray;
	}

	public void setSpecParamArray(ArrayList<Speciality> specParamArray) {
		this.specParamArray = specParamArray;
	}

	
	@Override
	public String execute() throws Exception {
		Connection conn=DBConn.createDBConn();
		//----�����Ҫ����һ��רҵ�������ع���---
		if("add".equals(action)){
			if(specialityname!=null&&specialityname.length()>0){
				String sql="select * from Speciality where SpecialityName=?";
				PreparedStatement preSQLSelect=conn.prepareStatement(sql);
				preSQLSelect.setString(1,specialityname);
				ResultSet rs=preSQLSelect.executeQuery();
				if(!rs.next()&&specialityname!=null){//û�����רҵ������Ĳ��ǿղ��ܲ���
					sql="insert into Speciality(SpecialityName) values(?)";
					PreparedStatement preSQLInsert=conn.prepareStatement(sql);
					preSQLInsert.setString(1,specialityname);
					preSQLInsert.executeUpdate();
					System.out.println("¼��רҵ���ݳɹ�");
				}
				else{
					addActionError("רҵ�Ѿ�����");
					
					//��ʾȫ����Ϣ(������Ĵ����ظ���)
					String sql1="select * from Speciality";
					Statement state=conn.createStatement();
					ResultSet rss=state.executeQuery(sql1);
					ArrayList<Speciality> specialityArray=new ArrayList<Speciality>();
					while(rss.next()){
						Speciality spec=new Speciality();
						spec.setSpecialityid(rss.getInt("specialityid"));
						spec.setSpecialityname(rss.getString("specialityname"));
						specialityArray.add(spec);
					}
					Map<String,ArrayList<Speciality>> request = (Map<String,ArrayList<Speciality>>)ActionContext.getContext().get("request");
					request.put("specialityArray", specialityArray);
						
					DBConn.closeConn(conn);
					return "fail";
				}
			}
			else{
				addActionError("û������");
				
				//��ʾȫ����Ϣ(������Ĵ����ظ���)
				String sql="select * from Speciality";
				Statement state=conn.createStatement();
				ResultSet rs=state.executeQuery(sql);
				ArrayList<Speciality> specialityArray=new ArrayList<Speciality>();
				while(rs.next()){
					Speciality spec=new Speciality();
					spec.setSpecialityid(rs.getInt("specialityid"));
					spec.setSpecialityname(rs.getString("specialityname"));
					specialityArray.add(spec);
				}
				Map<String,ArrayList<Speciality>> request = (Map<String,ArrayList<Speciality>>)ActionContext.getContext().get("request");
				request.put("specialityArray", specialityArray);
					
				DBConn.closeConn(conn);
				return "fail";
			}
		}
		//----�����ɾ��һ��רҵ----
		if("del".equals(action)){
			String sql="delete from Speciality where SpecialityId=?";
			PreparedStatement preSQLDel=conn.prepareStatement(sql);
			preSQLDel.setInt(1,specialityid);
			preSQLDel.executeUpdate();
		}
		/*�޸�רҵ*/
		if("update".equals(action)){
				System.out.println("�޸Ĳ���1");
				System.out.println(specialityname);
			    String sqlstr="update Speciality set SpecialityName = 'en' where SpecialityId=19";
			    PreparedStatement preSQLDel=conn.prepareStatement(sqlstr);
				preSQLDel.executeUpdate();
				Statement state=conn.createStatement();
			    state.executeUpdate(sqlstr);
		}
		
		//----��ѯ�����е�רҵ���ݲ������洢��request��specialityArray�б���jsp���----
		/*System.out.println("����2");*/
		String sql="select * from Speciality";
		Statement state=conn.createStatement();
		ResultSet rs=state.executeQuery(sql);
		ArrayList<Speciality> specialityArray=new ArrayList<Speciality>();
		while(rs.next()){
			Speciality spec=new Speciality();
			spec.setSpecialityid(rs.getInt("specialityid"));
			spec.setSpecialityname(rs.getString("specialityname"));
			specialityArray.add(spec);
		}
		Map<String,ArrayList<Speciality>> request = (Map<String,ArrayList<Speciality>>)ActionContext.getContext().get("request");
		request.put("specialityArray", specialityArray);
			
		DBConn.closeConn(conn);
		return SUCCESS;
	}

	public String getSpecialityname() {
		return specialityname;
	}

	public void setSpecialityname(String specialityname) {
		this.specialityname = specialityname;
	}

	public int getSpecialityid() {
		return specialityid;
	}

	public void setSpecialityid(int specialityid) {
		this.specialityid = specialityid;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}
}
