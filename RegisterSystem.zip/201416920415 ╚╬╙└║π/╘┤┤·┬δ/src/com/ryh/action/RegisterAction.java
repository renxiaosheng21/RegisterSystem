package com.ryh.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.opensymphony.xwork2.ActionSupport;
import com.ryh.db.DBConn;

public class RegisterAction extends ActionSupport{
	private static final long serialVersionUID = 1L;
	public String action;
	private String adminusername;
	private String adminuserpassword;
	private String againpassword;
	public String adminuserrole;
	public String errormsg;  
	public String getAdminuserrole() {
		return adminuserrole;
	}

	public void setAdminuserrole(String adminuserrole) {
		this.adminuserrole = adminuserrole;
	}

	public String getAdminusername() {
		return adminusername;
	}

	public void setAdminusername(String adminusername) {
		this.adminusername = adminusername;
	}

	public String getAdminuserpassword() {
		return adminuserpassword;
	}

	public void setAdminuserpassword(String adminuserpassword) {
		this.adminuserpassword = adminuserpassword;
	}

	public String getAgainpassword() {
		return againpassword;
	}

	public void setAgainpassword(String againpassword) {
		this.againpassword = againpassword;
	}

	public String execute() throws Exception {
		Connection conn=DBConn.createDBConn();
		//----�����Ҫ����һ���û�---
		if("add".equals(action)){
			String sql="select * from adminuser where adminusername=?";
			PreparedStatement preSQLSelect=conn.prepareStatement(sql);
			preSQLSelect.setString(1,adminusername);
			ResultSet rs=preSQLSelect.executeQuery();
			if(!rs.next()){//û������û�
				sql="insert into adminuser(adminuserName,adminuserpassword,adminuserrole) values(?,?,?)";
				PreparedStatement preSQLInsert=conn.prepareStatement(sql);
				preSQLInsert.setString(1,adminusername);
				preSQLInsert.setString(2,adminuserpassword);
				preSQLInsert.setString(3,adminuserrole);
				preSQLInsert.executeUpdate();
				return SUCCESS;
			}
			else{
				errormsg=new String("���û����Ѿ���ע��");
			}
		}
		return INPUT;
		
	}
}
