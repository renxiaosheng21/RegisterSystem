package com.ryh.action;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ryh.bean.ClassTa;
import com.ryh.bean.Student;
import com.ryh.db.DBConn;

public class ClassViewAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	public String action;
	public String classid;
	@Override
	public String execute() throws Exception {
		Connection conn=DBConn.createDBConn();
		
		//�Ѱ༶�б��洢��classArray��
		String sql="select * from ClassTa";
		Statement stclass=conn.createStatement();
		ResultSet rsclass=stclass.executeQuery(sql);
		ArrayList<ClassTa> classArray=new ArrayList<ClassTa>();
		while(rsclass.next()){
			ClassTa classta=new ClassTa();
			classta.setClassid(rsclass.getInt("classid"));
			classta.setClassname(rsclass.getString("classname"));
			classArray.add(classta);
		}
		Map request = (Map)ActionContext.getContext().get("request");
		request.put("classArray", classArray);
		
		//����༶��ѯ���������
		if(classid!=null&&classid.length()!=0){
			sql="select * from student where classid="+classid;
			Statement state=conn.createStatement();
			ResultSet rs=state.executeQuery(sql);
			ArrayList<Student> stuArray=new ArrayList<Student>();
			while(rs.next()){
				Student stu=new Student();
				stu.setBedchamberId(rs.getInt("bedchamberId"));
				stu.setClassId(rs.getInt("classId"));
				stu.setMatriNo(rs.getString("matriNo"));
				stu.setPayAmount(rs.getFloat("payAmount"));
				stu.setSpecialityId(rs.getInt("specialityId"));
				stu.setStudentId(rs.getLong("studentId"));
				stu.setStudentName(rs.getString("studentName"));
				stuArray.add(stu);
			}
			request.put("stuArray", stuArray);
		}
		DBConn.closeConn(conn);
		return SUCCESS;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}

}
