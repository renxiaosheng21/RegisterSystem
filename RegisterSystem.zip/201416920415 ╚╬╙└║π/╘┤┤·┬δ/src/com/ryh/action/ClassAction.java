package com.ryh.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ryh.bean.ClassTa;
import com.ryh.db.DBConn;

public class ClassAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	public String action;
	public String classname;
	public String classid;
	public ArrayList<Class> classParamArray;
	public ArrayList<Class> getClassParamArray() {
		return classParamArray;
	}
	public void setClassParamArray(ArrayList<Class> classParamArray) {
		this.classParamArray = classParamArray;
	}
	/*public void validate()
	{
		System.out.println("����validate��������У��");
		if(classname == null)
		{
			addFieldError("bedchambername" , "רҵ�������룡");
			System.out.println("У��ɹ���");
		}
	}*/
	@Override
	public String execute() throws Exception {
		Connection conn=DBConn.createDBConn();
		//----�����Ҫ����һ���༶---
		if("add".equals(action)){
			if(classname!=null&&classname.length()>0){
				String sql="select * from classta where classname=?";
				PreparedStatement preSQLSelect=conn.prepareStatement(sql);
				preSQLSelect.setString(1,classname);
				ResultSet rs=preSQLSelect.executeQuery();
				if(!rs.next()){//û������༶
					sql="insert into classta(className) values(?)";
					PreparedStatement preSQLInsert=conn.prepareStatement(sql);
					preSQLInsert.setString(1,classname);
					preSQLInsert.executeUpdate();
				}
				else{
					System.out.println("�������");
//					out.print("<script>alert('��Ǹ������������ʧЧ��')</script>");
					addActionError("�༶�Ѵ���");
					
					//��ʾȫ����Ϣ(������Ĵ����ظ���)
					String sql1="select * from classta";
					Statement state=conn.createStatement();
					ResultSet rss=state.executeQuery(sql1);
					ArrayList<ClassTa> classArray=new ArrayList<ClassTa>();
					while(rss.next()){
						ClassTa cla=new ClassTa();
						cla.setClassid(rss.getInt("classid"));
						cla.setClassname(rss.getString("classname"));
						classArray.add(cla);
					}
					Map<String,ArrayList<ClassTa>> request = (Map<String,ArrayList<ClassTa>>)ActionContext.getContext().get("request");
					request.put("classArray", classArray);
					DBConn.closeConn(conn);
					return "fail";
				}
				
			}
			else{
				System.out.println("�������");
//				out.print("<script>alert('��Ǹ������������ʧЧ��')</script>");
				addActionError("û������");
				
				//��ʾȫ����Ϣ(������Ĵ����ظ���)
				String sql="select * from classta";
				Statement state=conn.createStatement();
				ResultSet rs=state.executeQuery(sql);
				ArrayList<ClassTa> classArray=new ArrayList<ClassTa>();
				while(rs.next()){
					ClassTa cla=new ClassTa();
					cla.setClassid(rs.getInt("classid"));
					cla.setClassname(rs.getString("classname"));
					classArray.add(cla);
				}
				Map<String,ArrayList<ClassTa>> request = (Map<String,ArrayList<ClassTa>>)ActionContext.getContext().get("request");
				request.put("classArray", classArray);
				DBConn.closeConn(conn);
				return "fail";
			}
			
		}
		//----�����ɾ��һ���༶----
		if("del".equals(action)){
			String sql="delete from classta where classId=?";
			PreparedStatement preSQLDel=conn.prepareStatement(sql);
			int classidInt=0;
			if(classid!=null&&classid.length()>0)
				classidInt=Integer.parseInt(classid);
			preSQLDel.setInt(1,classidInt);
			preSQLDel.executeUpdate();
		}
		//----��ѯ�����еİ༶����----
		String sql="select * from classta";
		Statement state=conn.createStatement();
		ResultSet rs=state.executeQuery(sql);
		ArrayList<ClassTa> classArray=new ArrayList<ClassTa>();
		while(rs.next()){
			ClassTa cla=new ClassTa();
			cla.setClassid(rs.getInt("classid"));
			cla.setClassname(rs.getString("classname"));
			classArray.add(cla);
		}
		Map<String,ArrayList<ClassTa>> request = (Map<String,ArrayList<ClassTa>>)ActionContext.getContext().get("request");
		request.put("classArray", classArray);
		DBConn.closeConn(conn);
		return SUCCESS;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public String getClassid() {
		return classid;
	}
	public void setClassid(String classid) {
		this.classid = classid;
	}
}
