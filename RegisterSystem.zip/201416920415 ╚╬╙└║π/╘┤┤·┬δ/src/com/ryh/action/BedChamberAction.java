package com.ryh.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ryh.bean.Bedchamber;
import com.ryh.db.DBConn;

public class BedChamberAction extends ActionSupport{
	private static final long serialVersionUID = 1L;
	public String action;
	public String bedchambername;
	public String bedchamberid;
	
	@Override
	public String execute() throws Exception {
		Connection conn=DBConn.createDBConn();
		//----�����Ҫ����һ������---
		if("add".equals(action)){
			if(bedchambername!=null&&bedchambername.length()>0){
				String sql="select * from bedchamber where bedchambername=?";
				PreparedStatement preSQLSelect=conn.prepareStatement(sql);
				preSQLSelect.setString(1,bedchambername);
				ResultSet rs=preSQLSelect.executeQuery();
				if(!rs.next()&&bedchambername!=null){//û���������
					sql="insert into bedchamber(bedchamberName) values(?)";
					PreparedStatement preSQLInsert=conn.prepareStatement(sql);
					preSQLInsert.setString(1,bedchambername);
					preSQLInsert.executeUpdate();
				}
				else{
					System.out.println("���������");
					addActionError("�����Ѵ���");
					
					String sql1="select * from bedchamber";
					Statement state=conn.createStatement();
					ResultSet rs1=state.executeQuery(sql1);
					ArrayList<Bedchamber> bedArray=new ArrayList<Bedchamber>();
					while(rs1.next()){
						Bedchamber bed=new Bedchamber();
						bed.setBedchamberId(rs1.getInt("bedchamberId"));
						bed.setBedchamberName(rs1.getString("bedchamberName"));
						bedArray.add(bed);
					}
					Map<String,ArrayList<Bedchamber>> request = (Map<String,ArrayList<Bedchamber>>)ActionContext.getContext().get("request");
					request.put("bedArray", bedArray);
					DBConn.closeConn(conn);
					return "fail";
				}
			}
			else{
				System.out.println("��������Ϊ��");
				addActionError("����Ϊ��");
				
				//��ʾȫ����Ϣ(������Ĵ����ظ���)
				String sql="select * from bedchamber";
				Statement state=conn.createStatement();
				ResultSet rs=state.executeQuery(sql);
				ArrayList<Bedchamber> bedArray=new ArrayList<Bedchamber>();
				while(rs.next()){
					Bedchamber bed=new Bedchamber();
					bed.setBedchamberId(rs.getInt("bedchamberId"));
					bed.setBedchamberName(rs.getString("bedchamberName"));
					bedArray.add(bed);
				}
				Map<String,ArrayList<Bedchamber>> request = (Map<String,ArrayList<Bedchamber>>)ActionContext.getContext().get("request");
				request.put("bedArray", bedArray);
				DBConn.closeConn(conn);
				return "fail";
			}
		}
		//----�����ɾ��һ������----
		if("del".equals(action)){
			String sql="delete from bedchamber where bedchamberId=?";
			PreparedStatement preSQLDel=conn.prepareStatement(sql);
			int bedchamberidInt=0;
			if(bedchamberid!=null&&bedchamberid.length()>0)
				bedchamberidInt=Integer.parseInt(bedchamberid);
			preSQLDel.setInt(1,bedchamberidInt);
			preSQLDel.executeUpdate();
		}
		//----��ѯ�����е���������----
		String sql="select * from bedchamber";
		Statement state=conn.createStatement();
		ResultSet rs=state.executeQuery(sql);
		ArrayList<Bedchamber> bedArray=new ArrayList<Bedchamber>();
		while(rs.next()){
			Bedchamber bed=new Bedchamber();
			bed.setBedchamberId(rs.getInt("bedchamberId"));
			bed.setBedchamberName(rs.getString("bedchamberName"));
			bedArray.add(bed);
		}
		Map<String,ArrayList<Bedchamber>> request = (Map<String,ArrayList<Bedchamber>>)ActionContext.getContext().get("request");
		request.put("bedArray", bedArray);
		DBConn.closeConn(conn);
		return SUCCESS;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public String getBedchambername() {
		return bedchambername;
	}

	public void setBedchambername(String bedchambername) {
		this.bedchambername = bedchambername;
	}

	public String getBedchamberid() {
		return bedchamberid;
	}

	public void setBedchamberid(String bedchamberid) {
		this.bedchamberid = bedchamberid;
	}
	
}
