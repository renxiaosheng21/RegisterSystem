package com.ryh.action;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ryh.bean.Student;
import com.ryh.db.DBConn;

public class MoneyAdminAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	public String studentname;
	public String action;
	public String matrino;
	public ArrayList<Student> stuParamArray;
	
	@Override
	public String execute() throws Exception {
		Connection conn=DBConn.createDBConn();
		//----�ɷѲ���----
		String sql=new String("");
		if(stuParamArray!=null&&"update".equals(action)){
			for(int i=0;i<stuParamArray.size();i++){
				if(stuParamArray.get(i).getClassId()==0){
					String sqlstr="update student set payamount="+stuParamArray.get(i).getPayAmount()+
						" where studentid="+stuParamArray.get(i).getStudentId();
					Statement state=conn.createStatement();
					state.executeUpdate(sqlstr);
					System.out.println("�ɷѳɹ�");
				}	
			}
		}
		sql="select * from student ";
		Statement state=conn.createStatement();
		ResultSet rs=state.executeQuery(sql);
		ArrayList<Student> stuArray=new ArrayList<Student>();
		while(rs.next()){
			Student stu=new Student();
			stu.setBedchamberId(rs.getInt("bedchamberId"));
			stu.setClassId(rs.getInt("classId"));
			stu.setMatriNo(rs.getString("matriNo"));
			stu.setPayAmount(rs.getInt("payAmount"));

			stu.setSpecialityId(rs.getInt("specialityId"));
			stu.setStudentId(rs.getLong("studentId"));
			stu.setStudentName(rs.getString("studentName"));
			stuArray.add(stu);
		}
		Map request = (Map)ActionContext.getContext().get("request");
		request.put("stuArray", stuArray);			
		//----���Ѳ���----
		
		DBConn.closeConn(conn);
		return SUCCESS;
	}
	public ArrayList<Student> getStuParamArray() {
		return stuParamArray;
	}
	public void setStuParamArray(ArrayList<Student> stuParamArray) {
		this.stuParamArray = stuParamArray;
	}
	public String getStudentname() {
		
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getMatrino() {
		return matrino;
	}
	public void setMatrino(String matrino) {
		this.matrino = matrino;
	}

}
