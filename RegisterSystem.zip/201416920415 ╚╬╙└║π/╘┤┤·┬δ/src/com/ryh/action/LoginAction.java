package com.ryh.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.ryh.db.DBConn;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	private static final long serialVersionUID = 1L;
	public String adminusername;
	public String adminuserpassword;
	public String action;
	public String errormsg;

	@Override
	public String execute() {
		if("login".equals(action)){
			try{
				Connection conn=DBConn.createDBConn();
				String sql="select * from adminuser where adminusername=? and adminuserpassword=?";
				PreparedStatement state=conn.prepareStatement(sql);
				state.setString(1,adminusername);
				state.setString(2,adminuserpassword);
				ResultSet rs=state.executeQuery();
				if(rs.next()){//����û�����������ȷ
					HttpSession session = ServletActionContext.getRequest().getSession();
					session.setAttribute("adminusername", adminusername);
					//ActionContext.getContext().getSession().put("adminusername",adminusername);
					ActionContext.getContext().getSession().put("adminuserpassword",adminusername);
					ActionContext.getContext().getSession().put("adminuserrole",rs.getString("adminuserrole"));
					DBConn.closeConn(conn);
					return SUCCESS;
				}
				else{
					errormsg=new String("�û�����������������");					
				}	
				DBConn.closeConn(conn);
			}catch(Exception e){
				errormsg=new String("���ݿ���������");
			}	
		}
		
		return INPUT;
	}

}
