package com.ryh.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ryh.bean.Speciality;
import com.ryh.bean.Student;
import com.ryh.db.DBConn;

public class StudentAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	public String action;
	public int specialityid;
	public String matrino;
	public String studentname;
	public int currentpage=1;
	public long studentid;
	@Override
	public String execute() throws Exception {
		if(studentname!=null&&studentname.length()!=0)
			studentname=studentname.trim();
		if(action!=null&&action.length()!=0)
			action=action.trim();
		if(matrino!=null&&matrino.length()!=0)
			matrino=matrino.trim();
		Connection conn=DBConn.createDBConn();
		//----�����Ҫ����һ��ѧ��---
		if("add".equals(action)){
			String sql="select * from Student where matrino=? and studentname=?"+
				" and specialityid=?";
			PreparedStatement preSQLSelect=conn.prepareStatement(sql);
			preSQLSelect.setString(1,matrino);
			preSQLSelect.setString(2,studentname);
			preSQLSelect.setInt(3,specialityid);
			ResultSet rs=preSQLSelect.executeQuery();
			if(!rs.next()&&studentname.length()>0&&matrino.length()>0){//û�����רҵ
				sql="insert into Student(matrino,studentname,specialityid) "+
					" values(?,?,?)";
				PreparedStatement preSQLInsert=conn.prepareStatement(sql);
				preSQLInsert.setString(1,matrino);
				preSQLInsert.setString(2,studentname);
				preSQLInsert.setInt(3,specialityid);
				preSQLInsert.executeUpdate();
			}
		}
		//----�����Ҫɾ��һ��ѧ��---
		if("del".equals(action)){
			String sql="delete from Student where studentid=?";
			PreparedStatement preSQLUpdate=conn.prepareStatement(sql);
			preSQLUpdate.setLong(1,studentid);
			preSQLUpdate.executeUpdate();
		}
		//----�����Ҫ��ѯ����----
		ResultSet rsselect=null;
		int pagesize=5;//ÿҳ��¼����
		int pagecount=0;//��ҳ��
		int recount=0;//�ܼ�¼����
		
		//if("select".equals(action)){
		String sql=null;
		sql="select top "+pagesize+" studentname,"+
			"studentid,matrino,specialityid "+
			"from Student order by studentid desc";
		
		//���¼����ǵõ��ܼ�¼��
		String sqlcount="select count(*) as recount from Student ";
		Statement stateCount=conn.createStatement();
		ResultSet rscount=stateCount.executeQuery(sqlcount);
		rscount.next();
		recount=rscount.getInt("recount");//�õ��ܼ�¼����
		//----�õ���ҳ��----
		if(recount%pagesize==0)//������
			pagecount=recount/pagesize;
		else//��������
			pagecount=(int)(recount/pagesize)+1;
		//----���ɵõ���ǰҳ���ݲ�ѯ�ĸ�������----
		if(pagecount>1&&currentpage>1){
			System.out.println("���ǵ�"+currentpage+"ҳ");
			System.out.println((currentpage-1)*pagesize);
			int a=(currentpage-1)*pagesize;
			sql="select * from Student order by studentid desc limit "+a+",5";
		}
		Statement state=conn.createStatement();
		rsselect=state.executeQuery(sql);
			
		ArrayList<Student> stuArray=new ArrayList<Student>();
		while(rsselect!=null&&rsselect.next()){
			Student stu=new Student();
			stu.setStudentName(rsselect.getString("studentname"));
			stu.setSpecialityId(rsselect.getInt("specialityid"));
			stu.setMatriNo(rsselect.getString("matrino"));
			stu.setStudentId(rsselect.getLong("studentid"));
			stuArray.add(stu);
		}
		Map map = (Map)ActionContext.getContext().get("request");
		map.remove("stuArray");
		map.put("stuArray", stuArray);		
		//----��ѯ��רҵ����----
		String sql1="select * from Speciality";
		Statement state1=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
		ResultSet rs=state1.executeQuery(sql1);
		ArrayList<Speciality> specialityArray=new ArrayList<Speciality>();
		while(rs.next()){
			Speciality spec=new Speciality();
			spec.setSpecialityid(rs.getInt("specialityid"));
			spec.setSpecialityname(rs.getString("specialityname"));
			specialityArray.add(spec);
		}
		map.remove("specialityArray");
		map.put("specialityArray", specialityArray);
		//----�����ݷ���request----
		map.remove("pagesize");
		map.remove("pagecount");
		map.remove("currentpage");
		map.remove("recount");
		map.put("pagesize",pagesize);
		map.put("pagecount",pagecount);
		map.put("currentpage",currentpage);
		map.put("recount",recount);
		DBConn.closeConn(conn);
		return SUCCESS;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public int getSpecialityid() {
		return specialityid;
	}

	public void setSpecialityid(int specialityid) {
		this.specialityid = specialityid;
	}

	public String getMatrino() {
		return matrino;
	}

	public void setMatrino(String matrino) {
		this.matrino = matrino;
	}

	public String getStudentname() {
		return studentname;
	}

	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}

	public int getCurrentpage() {
		return currentpage;
	}

	public void setCurrentpage(int currentpage) {
		this.currentpage = currentpage;
	}

	public long getStudentid() {
		return studentid;
	}

	public void setStudentid(long studentid) {
		this.studentid = studentid;
	}

}
