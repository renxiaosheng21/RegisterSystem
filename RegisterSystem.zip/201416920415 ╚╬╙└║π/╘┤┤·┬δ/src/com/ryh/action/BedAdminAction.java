package com.ryh.action;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
import com.ryh.bean.Bedchamber;
import com.ryh.bean.Student;
import com.ryh.db.DBConn;

public class BedAdminAction extends ActionSupport {

	private static final long serialVersionUID = 1L;
	public String studentname;
	public String action;
	public String matrino;
	public ArrayList<Student> stuParamArray;
	@Override
	public String execute() throws Exception {
		Connection conn=DBConn.createDBConn();
		String sql=new String("");
		Map request = (Map)ActionContext.getContext().get("request");
		
		//----��������----
		if(stuParamArray!=null&&"update".equals(action)){
			for(int i=0;i<stuParamArray.size();i++){
				if(stuParamArray.get(i).getBedchamberId()!=0){
					String sqlstr="update student set bedchamberid="+stuParamArray.get(i).getBedchamberId()+
						" where studentid="+stuParamArray.get(i).getStudentId();
					System.out.println(sqlstr);
					Statement stateBed=conn.createStatement();
					stateBed.executeUpdate(sqlstr);
				}	
			}
		}
		//----����ǲ�ѯ����----
		sql="select * from student ";
		Statement state=conn.createStatement();
		ResultSet rs=state.executeQuery(sql);
		ArrayList<Student> stuArray=new ArrayList<Student>();
		while(rs!=null&&rs.next()){
			Student stu=new Student();
			stu.setStudentName(rs.getString("studentname"));
			stu.setSpecialityId(rs.getInt("specialityid"));
			stu.setMatriNo(rs.getString("matrino"));
			stu.setStudentId(rs.getLong("studentid"));
			stu.setClassId(rs.getInt("classid"));
			stu.setPayAmount(rs.getFloat("payAmount"));
			/*stu.setPayOK(rs.getInt("payok"));*/
			stu.setBedchamberId(rs.getInt("bedchamberId"));
			stuArray.add(stu);
		}
		request.put("stuArray", stuArray);
		//}
		//----��ѯ�������嵥----
		sql="select * from bedchamber";
		Statement statebed=conn.createStatement();
		ResultSet rsbed=statebed.executeQuery(sql);
		ArrayList<Bedchamber> bedArray=new ArrayList<Bedchamber>();
		while(rsbed.next()){
			Bedchamber bed=new Bedchamber();
			bed.setBedchamberId(rsbed.getInt("bedchamberId"));
			bed.setBedchamberName(rsbed.getString("bedchamberName"));
			bedArray.add(bed); 
		}
		request.put("bedArray", bedArray);
		
		DBConn.closeConn(conn);
		return SUCCESS;
	}
	public String getStudentname() {
		return studentname;
	}
	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getMatrino() {
		return matrino;
	}
	public void setMatrino(String matrino) {
		this.matrino = matrino;
	}
	public ArrayList<Student> getStuParamArray() {
		return stuParamArray;
	}
	public void setStuParamArray(ArrayList<Student> stuParamArray) {
		this.stuParamArray = stuParamArray;
	}

}
