package com.ryh.db;
import java.sql.Connection;
import java.sql.DriverManager;
public class DBConn {

	//�õ����ݿ�����
	public static Connection createDBConn(){
		 Connection con = null;  
	
		try{
			Class.forName("org.hsqldb.jdbcDriver");  
			//con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost:9001/RegisterSystem", "SA" , "") ;
	       // con = DriverManager.getConnection("jdbc:hsqldb:file:E:\\hsqldb\\data\\RegisterSystem", "SA", ""); 
	        con = DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/RegisterSystem", "SA" , "") ;
			return con;
			
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
	//�ر����ݿ�����
	public static void closeConn(Connection conn){
		try{
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
