package com.ryh.bean;

public class Speciality {
	public int specialityid;
	public String specialityname;
	public int getSpecialityid() {
		return specialityid;
	}
	public void setSpecialityid(int specialityid) {
		this.specialityid = specialityid;
	}
	public String getSpecialityname() {
		return specialityname;
	}
	public void setSpecialityname(String specialityname) {
		this.specialityname = specialityname;
	}
}
