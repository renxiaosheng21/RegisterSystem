package com.ryh.bean;

public class Bedchamber {
	public int bedchamberId;
	public String bedchamberName;
	public int getBedchamberId() {
		return bedchamberId;
	}
	public void setBedchamberId(int i) {
		this.bedchamberId = i;
	}
	public String getBedchamberName() {
		return bedchamberName;
	}
	public void setBedchamberName(String bedchamberName) {
		this.bedchamberName = bedchamberName;
	}
	
}
