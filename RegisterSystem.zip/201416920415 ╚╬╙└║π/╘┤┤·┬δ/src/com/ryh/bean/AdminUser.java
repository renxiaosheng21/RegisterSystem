package com.ryh.bean;

public class AdminUser {
	public String adminusername;
	public String adminuserpassword;
	public int adminuserrole;
	
	public String getAdminusername() {
		return adminusername;
	}
	public void setAdminusername(String adminusername) {
		this.adminusername = adminusername;
	}
	public String getAdminuserpassword() {
		return adminuserpassword;
	}
	public void setAdminuserpassword(String adminuserpassword) {
		this.adminuserpassword = adminuserpassword;
	}
	public int getAdminuserrole() {
		return adminuserrole;
	}
	public void setAdminuserrole(int adminuserrole) {
		this.adminuserrole = adminuserrole;
	}

	
}
